// 예시 공지 데이터입니다. 실제 공지로 바꿔서 사용할 수 있습니다.
const notices = [
    {
        title: "2026학년도 2학기 기말고사 시간표 안내",
        category: "시험",
        date: "2026-11-10",
        description: "기말고사 일정 및 강의실을 확인하세요."
    },
    {
        title: "2026학년도 2학기 성적 확인 안내",
        category: "학사",
        date: "2026-11-08",
        description: "성적 확인 및 이의신청 일정을 안내합니다."
    },
    {
        title: "2026학년도 2학기 장학금 신청 안내",
        category: "장학금",
        date: "2026-11-05",
        description: "장학금 신청 기간과 제출 서류를 확인하세요."
    }
];

function displayNotices(list) {
    const noticeList = document.getElementById("noticeList");
    noticeList.replaceChildren();

    if (list.length === 0) {
        const message = document.createElement("p");
        message.className = "empty-message";
        message.textContent = "검색 결과가 없습니다.";
        noticeList.appendChild(message);
        return;
    }

    list.forEach((notice) => {
        const card = document.createElement("article");
        card.className = "notice";

        const title = document.createElement("h3");
        title.textContent = notice.title;

        const category = document.createElement("p");
        category.textContent = `분류: ${notice.category}`;

        const date = document.createElement("p");
        date.textContent = `등록일: ${notice.date}`;

        const description = document.createElement("p");
        description.textContent = notice.description;

        card.append(title, category, date, description);
        noticeList.appendChild(card);
    });
}

function filterNotice(category) {
    const filtered = category === "전체"
        ? notices
        : notices.filter((notice) => notice.category === category);

    displayNotices(filtered);
}

function searchNotice() {
    const keyword = document.getElementById("searchInput").value.trim();

    const result = notices.filter((notice) =>
        notice.title.includes(keyword) ||
        notice.description.includes(keyword)
    );

    displayNotices(result);
}

document.getElementById("searchButton").addEventListener("click", searchNotice);

document.getElementById("searchInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        searchNotice();
    }
});

document.querySelectorAll(".categories button").forEach((button) => {
    button.addEventListener("click", () => {
        filterNotice(button.dataset.category);
    });
});

displayNotices(notices);
